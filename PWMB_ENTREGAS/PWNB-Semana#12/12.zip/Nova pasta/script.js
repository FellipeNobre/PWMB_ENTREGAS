// script.js

const clientes = [];
const form = document.querySelector('#cadastro form');
const lista = document.querySelector('#lista tbody');

form.addEventListener('submit', (e) => {
  e.preventDefault();

  const nome = document.querySelector('#nome').value;
  const sobrenome = document.querySelector('#sobrenome').value;
  const tipoCliente = document.querySelector('#tipo-cliente').value;
  const dataNascimento = document.querySelector('#data-nascimento').value;
  const cep = document.querySelector('#cep').value;
  const cidade = document.querySelector('#cidade').value;
  const endereco = document.querySelector('#endereco').value;
  const numero = document.querySelector('#numero').value;

  // Validação dos campos usando expressões regulares

  if (!validarNome(nome)) {
    alert('Nome inválido. Deve conter apenas letras e espaços.');
    return;
  }

  if (!validarSobrenome(sobrenome)) {
    alert('Sobrenome inválido. Deve conter apenas letras e espaços.');
    return;
  }

  if (!validarDataNascimento(dataNascimento)) {
    alert('Data de Nascimento inválida. Deve estar no formato AAAA-MM-DD.');
    return;
  }

  if (!validarCEP(cep)) {
    alert('CEP inválido. Deve estar no formato nnnnn-ccc.');
    return;
  }

  if (!validarCidade(cidade)) {
    alert('Cidade inválida. Deve conter apenas letras e espaços.');
    return;
  }

  if (!validarEndereco(endereco)) {
    alert('Endereço inválido. Deve conter apenas letras, números e espaços.');
    return;
  }

  if (!validarNumero(numero)) {
    alert('Número inválido. Deve conter apenas números.');
    return;
  }

  // Se os campos forem válidos, adicione o cliente à lista
  if (nome && sobrenome && tipoCliente && dataNascimento && cep && cidade && endereco && numero) {
    const cliente = { nome, sobrenome, tipoCliente, dataNascimento, cep, cidade, endereco, numero };
    clientes.push(cliente);
    atualizarLista();
    form.reset();
  }
});

function validarNome(nome) {
  const nomeRegex = /^[A-Za-zÀ-ÖØ-öø-ÿ\s]+$/;
  return nomeRegex.test(nome);
}

function validarSobrenome(sobrenome) {
  const sobrenomeRegex = /^[A-Za-zÀ-ÖØ-öø-ÿ\s]+$/;
  return sobrenomeRegex.test(sobrenome);
}

function validarDataNascimento(dataNascimento) {
  const dataNascimentoRegex = /^\d{4}-\d{2}-\d{2}$/;
  return dataNascimentoRegex.test(dataNascimento);
}

function validarCEP(cep) {
  const cepRegex = /^\d{5}-\d{3}$/;
  return cepRegex.test(cep);
}

function validarCidade(cidade) {
  const cidadeRegex = /^[A-Za-zÀ-ÖØ-öø-ÿ\s]+$/;
  return cidadeRegex.test(cidade);
}

function validarEndereco(endereco) {
  const enderecoRegex = /^[A-Za-z0-9À-ÖØ-öø-ÿ\s]+$/;
  return enderecoRegex.test(endereco);
}

function validarNumero(numero) {
  const numeroRegex = /^\d+$/;
  return numeroRegex.test(numero);
}

function atualizarLista() {
  lista.innerHTML = '';

  clientes.forEach((cliente, index) => {
    const row = lista.insertRow();
    const cellNome = row.insertCell(0);
    const cellSobrenome = row.insertCell(1);
    const cellTipoCliente = row.insertCell(2);
    const cellDataNascimento = row.insertCell(3);
    const cellCep = row.insertCell(4);
    const cellCidade = row.insertCell(5);
    const cellEndereco = row.insertCell(6);
    const cellNumero = row.insertCell(7);
    const cellAcoes = row.insertCell(8);

    cellNome.textContent = cliente.nome;
    cellSobrenome.textContent = cliente.sobrenome;
    cellTipoCliente.textContent = cliente.tipoCliente;
    cellDataNascimento.textContent = cliente.dataNascimento;
    cellCep.textContent = cliente.cep;
    cellCidade.textContent = cliente.cidade;
    cellEndereco.textContent = cliente.endereco;
    cellNumero.textContent = cliente.numero;

    const excluirBotao = document.createElement('button');
    excluirBotao.textContent = 'Excluir';
    excluirBotao.classList.add('botao-excluir');
    excluirBotao.addEventListener('click', () => excluirCliente(index));

    const alterarBotao = document.createElement('button');
    alterarBotao.textContent = 'Alterar';
    alterarBotao.classList.add('botao-alterar');
    alterarBotao.addEventListener('click', () => alterarCliente(index));

    cellAcoes.appendChild(excluirBotao);
    cellAcoes.appendChild(alterarBotao);
  });
}

function excluirCliente(index) {
  clientes.splice(index, 1);
  atualizarLista();
}

function alterarCliente(index) {
  const cliente = clientes[index];

  document.querySelector('#nome').value = cliente.nome;
  document.querySelector('#sobrenome').value = cliente.sobrenome;
  document.querySelector('#tipo-cliente').value = cliente.tipoCliente;
  document.querySelector('#data-nascimento').value = cliente.dataNascimento;
  document.querySelector('#cep').value = cliente.cep;
  document.querySelector('#cidade').value = cliente.cidade;
  document.querySelector('#endereco').value = cliente.endereco;
  document.querySelector('#numero').value = cliente.numero;
}

// Inicializa a lista de clientes
atualizarLista();
